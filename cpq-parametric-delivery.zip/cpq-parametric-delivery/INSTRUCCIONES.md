# Modo Paramétrico CPQ - Instrucciones de Integración

## Contenido del paquete

```
cpq-parametric-delivery/
├── parametric/                    # Nuevo módulo (copiar a cpq/)
│   ├── __init__.py
│   ├── config_parametric.py
│   ├── limits_calculator.py
│   ├── shape_generator.py
│   ├── validator.py
│   └── cost_adapter.py
├── cli_parametric.py              # Nueva interfaz CLI (copiar a cpq/)
├── parametric-mode.patch          # Patch completo (alternativa)
└── INSTRUCCIONES.md               # Este archivo
```

## Opción A: Aplicar el patch (recomendado)

```bash
cd /ruta/a/tu/CPQ
git apply parametric-mode.patch
```

Si hay conflictos, usa:
```bash
git apply --3way parametric-mode.patch
```

## Opción B: Integración manual

### Paso 1: Copiar archivos nuevos
```bash
cp -r parametric/ /ruta/a/tu/CPQ/cpq/
cp cli_parametric.py /ruta/a/tu/CPQ/cpq/
```

### Paso 2: Modificar main.py

Añadir estos imports después de los imports de `cpq.cli`:

```python
from cpq.cli_parametric import (
    select_mode,
    display_parametric_limits,
    display_parametric_config,
    get_parametric_input,
    confirm_use_suggested,
    confirm_parametric_config,
)
from cpq.parametric import (
    ParametricLimitsCalculator,
    ShapeGenerator,
    ParametricValidator,
    ParametricModelAdapter,
    TechnicalConstraints,
)
from cpq.parametric.validator import ProgramEstimator
```

### Paso 3: Reemplazar PASO 5 y PASO 6 en main.py

Buscar la sección:
```python
# =========================================================================
# PASO 5: Filtrar modelos válidos
# =========================================================================
```

Y reemplazar PASO 5 + PASO 6 completos con el nuevo flujo que incluye:
1. `select_mode()` para elegir catálogo o paramétrico
2. Si paramétrico: calcular límites, generar config, validar
3. Si catálogo: flujo existente sin cambios

Ver el patch para el código exacto.

## Verificación

```bash
python main.py
# Debe mostrar la opción de elegir modo [1] Catálogo o [2] Paramétrico
```

## Qué hace el modo paramétrico

1. Calcula límites máximos de la parcela (ocupación, edificabilidad)
2. Sugiere configuración óptima de 2 plantas
3. Permite al usuario ajustar PB y P1 en m²
4. Soporta formas: _ (barra), I, L, U
5. Valida restricciones técnicas y normativas
6. Genera modelo compatible con el sistema de costes existente

El modo catálogo sigue funcionando exactamente igual.
